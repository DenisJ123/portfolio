package ie.atu.week8.projectexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
