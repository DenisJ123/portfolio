package ie.atu.week8.projectexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectExerciseApplication.class, args);
    }

}
