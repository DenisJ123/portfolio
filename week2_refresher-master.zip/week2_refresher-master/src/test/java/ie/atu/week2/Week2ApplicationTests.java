package ie.atu.week2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
