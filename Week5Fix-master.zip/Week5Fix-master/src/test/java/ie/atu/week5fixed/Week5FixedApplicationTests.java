package ie.atu.week5fixed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5FixedApplicationTests {

    @Test
    void contextLoads() {
    }

}
