package ie.atu.week3_recapb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3RecapBApplicationTests {

    @Test
    void contextLoads() {
    }

}
