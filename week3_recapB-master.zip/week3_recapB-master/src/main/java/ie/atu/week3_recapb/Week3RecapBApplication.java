package ie.atu.week3_recapb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week3RecapBApplication {

    public static void main(String[] args) {
        SpringApplication.run(Week3RecapBApplication.class, args);
    }

}
